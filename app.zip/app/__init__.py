"""ElecIO Publisher service."""

